/**
 * @file
 * JS for Radix Starter.
 */
(function ($) {
  // code here
})(jQuery);
